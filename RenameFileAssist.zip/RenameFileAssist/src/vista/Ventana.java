/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import modelo.Transformador;
/**
 *
 * @author Alumno
 */
public class Ventana extends JFrame implements ActionListener{
    
    private Panel panel;
    private Transformador transformar;

    public Ventana() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {

        this.panel = new Panel();
        this.add(this.panel, BorderLayout.CENTER);

        ImageIcon ImageIcon = new ImageIcon("imagenes//iconoCarp.jpg");
        Image image = ImageIcon.getImage();
        this.setIconImage(image);

        this.setSize(600, 400);
        this.setLocationRelativeTo(this);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setTitle("Beta");
        this.setVisible(true);

        this.panel.comenzar.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
    
        int cuenta = 0;
        if (this.panel.comenzar == e.getSource()) {

            JFileChooser selecto = new JFileChooser();
            
            selecto.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            selecto.setApproveButtonText("Seleccione una Carpeta");
            int val = selecto.showOpenDialog(null);

            if (val == JFileChooser.APPROVE_OPTION) {

                File rutaActual = selecto.getSelectedFile();
                File[] archivos = rutaActual.listFiles();
                for (int i = 0; i < archivos.length; i++) {
                    if (!archivos[i].isHidden()) {//La condición se cumple si y solo si el archivo no esta oculto
                        archivos[cuenta] = archivos[i];
                        cuenta++;
                    }
                }
                JOptionPane.showMessageDialog(this, "Archivos de la carpeta " + rutaActual.getName() + " renombrados exitosamente ");

                String nombreCarpeta = rutaActual.getName();
                this.transformar = new Transformador();
                
                for (int i = 0; i < archivos.length; i++) {

                    boolean cambio = archivos[i].renameTo(new File(rutaActual.getPath() + "\\" + nombreCarpeta + this.transformar.mostrarNumeros(i + 1, cuenta) + ".mp4"));
                    
                }
            }

        }
        
    }

    
    
    
}
