/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class Panel extends JPanel{
    
    private JLabel titulo1;
    private JLabel titulo2;
    public JButton comenzar;
    public JButton ayuda;
    
    public Panel() {
        
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
    
        this.setLayout( null );
        Font fuente=new Font("Permanent Marker", Font.BOLD, 60);
        this.titulo1 = new JLabel("Rename File");
        this.titulo1.setFont(fuente);
        this.titulo1.setForeground(Color.red);
        this.add(this.titulo1).setBounds(110, 50, 400, 55);
        
        this.titulo2 = new JLabel("assist");
        this.titulo2.setFont(fuente);
        this.titulo2.setForeground(Color.red);
        this.add(this.titulo2).setBounds(200, 110, 300, 55);
        
        ImageIcon botonComenzar = new ImageIcon("imagenes//comenzar.jpg");
        this.comenzar = new JButton(botonComenzar);
        
        this.add(this.comenzar).setBounds(210, 200, 181, 45);
        
        ImageIcon botonAyuda = new ImageIcon("imagenes//ayuda.jpg");
        this.ayuda = new JButton(botonAyuda);
        this.add(this.ayuda).setBounds(210, 270, 181, 45);
    
    }
    public void paint (Graphics g){
        
        int fila = 0;
        for (int azul = 0 ; azul <= 200 ; azul++)
        {
            Color col = new Color (0, 0, azul);
            g.setColor (col);
            g.drawLine (0, fila, 800, fila);
            fila++;
            g.drawLine (0, fila, 800, fila);
            fila++;
        }
        this.setOpaque(false);
        super.paint(g);
    }
    
}
