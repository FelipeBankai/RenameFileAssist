/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Alumno
 */
public class Transformador {
    
    public Transformador() {
        
    }
    
    public int contarCifrasNum(int ingresar) {
        
        int cifras = 0;
        
        while (ingresar != 0) {
            
            ingresar = ingresar / 10;
            
            cifras++;
            
        }
        return cifras;
        
    }
    
    public int potencia(int cifras) {
        
        int agregarCero = (int) Math.pow(10, cifras - 1);
        return agregarCero;
        
    }
    
    public String mostrarNumeros(int i, int valorMax) {
        
        
        String numero = contadorCero(i, valorMax);
        
        return numero;
    }
    
    public String contadorCero(int i, int numIngresado) {
        
        String numero = "";
        if (i < potencia(contarCifrasNum(numIngresado))) {
            
            numero = CerosNecesarios(i, numIngresado);
            
        } else {
            
            System.out.println(" "+i);//se cumple solo si y solo si, el numero no necesita anteponer un cero
            numero = " "+i;
        }
        return numero;
    }
    
    public String CerosNecesarios(int i, int numIngresado) {
        
        int compararCifra = i;
        String numero = "";
        
        int cifrasNumIngresado = contarCifrasNum(numIngresado);
        int cifrasComparador = contarCifrasNum(compararCifra);
        String aux = "";
        while (cifrasComparador != cifrasNumIngresado) {
            
            aux = aux + "0";
            cifrasComparador++;
        }
        
        System.out.println(" "+aux + i);
        numero = " "+aux + i;
        return numero;
        
    }
}
